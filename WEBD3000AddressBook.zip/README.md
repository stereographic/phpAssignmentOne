# phpAssignmentOne

## Summary
Assignment 1 for NSCC's Web Development program, given user stories and tasked to create a contact management system for a sales company.
This is for educational purposes, and as such it could be flawed. 
